package com.Ticket.ProjetS4.services;

import com.Ticket.ProjetS4.dto.TicketPurchaseRequest;
import com.Ticket.ProjetS4.dto.TicketPurchaseResponse;
import com.Ticket.ProjetS4.models.Match;
import com.Ticket.ProjetS4.models.TicketPurchase;
import com.Ticket.ProjetS4.repository.MatchRepository;
import com.Ticket.ProjetS4.repository.TicketPurchaseRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
public class TicketPurchaseService {
    private final TicketPurchaseRepository ticketPurchaseRepository;
    private final MatchRepository matchRepository;

    public TicketPurchaseService(TicketPurchaseRepository ticketPurchaseRepository, 
                               MatchRepository matchRepository) {
        this.ticketPurchaseRepository = ticketPurchaseRepository;
        this.matchRepository = matchRepository;
    }

    public TicketPurchaseResponse createPurchase(TicketPurchaseRequest request) {
        try {
            // Validate required fields
            if (request.getMatchId() == null) {
                throw new IllegalArgumentException("Match ID is required");
            }
            if (request.getCustomerEmail() == null || request.getCustomerEmail().trim().isEmpty()) {
                throw new IllegalArgumentException("Customer email is required");
            }

            // Find the match first
            Match match = matchRepository.findById(request.getMatchId())
                .orElseThrow(() -> new RuntimeException("Match not found with id: " + request.getMatchId()));

            TicketPurchase purchase = new TicketPurchase();
            
            // Set event name from match if not provided
            String eventName = request.getEventName();
            if (eventName == null || eventName.trim().isEmpty()) {
                eventName = match.getTeam1() + " vs " + match.getTeam2();
            }
            
            purchase.setEventName(eventName);
            purchase.setVenue(request.getVenue() != null ? request.getVenue() : match.getVenue());
            purchase.setPrice(request.getPrice() > 0 ? request.getPrice() : 
                            (match.getPrice() != null ? match.getPrice() : match.getTicketPrice()));
            purchase.setCustomerEmail(request.getCustomerEmail());
            purchase.setCustomerName(request.getCustomerName());
            purchase.setMatch(match);
            purchase.setQuantity(request.getQuantity() > 0 ? request.getQuantity() : 1);
            
            // Generate confirmation number if not provided
            String confirmationNumber = request.getConfirmationNumber();
            if (confirmationNumber == null || confirmationNumber.trim().isEmpty()) {
                confirmationNumber = "TKT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
            }
            purchase.setConfirmationNumber(confirmationNumber);
            
            purchase.setOrderId(request.getOrderId());
            purchase.setPaymentMethod(request.getPaymentMethod());
            purchase.setPurchaseDate(LocalDateTime.now());
            purchase.setIsUsed(0);

            TicketPurchase savedPurchase = ticketPurchaseRepository.save(purchase);
            return mapToResponse(savedPurchase);
        } catch (Exception e) {
            System.err.println("Error in createPurchase: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to create purchase: " + e.getMessage(), e);
        }
    }

    public List<TicketPurchaseResponse> getPurchasesByCustomerEmail(String customerEmail) {
        List<TicketPurchase> purchases = ticketPurchaseRepository.findByCustomerEmailOrderByPurchaseDateDesc(customerEmail);
        return purchases.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public TicketPurchaseResponse getPurchaseByConfirmationNumber(String confirmationNumber) {
        TicketPurchase purchase = ticketPurchaseRepository.findByConfirmationNumber(confirmationNumber)
                .orElseThrow(() -> new RuntimeException("Purchase not found with confirmation number: " + confirmationNumber));
        return mapToResponse(purchase);
    }

    public TicketPurchaseResponse getPurchaseById(Long id) {
        TicketPurchase purchase = ticketPurchaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Purchase not found with id: " + id));
        return mapToResponse(purchase);
    }

    public List<TicketPurchaseResponse> getPurchasesByMatchId(Long matchId) {
        List<TicketPurchase> purchases = ticketPurchaseRepository.findByMatchId(matchId);
        return purchases.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    private TicketPurchaseResponse mapToResponse(TicketPurchase purchase) {
        TicketPurchaseResponse response = new TicketPurchaseResponse();
        response.setId(purchase.getId());
        response.setEventName(purchase.getEventName());
        response.setVenue(purchase.getVenue());
        response.setPrice(purchase.getPrice());
        response.setCustomerEmail(purchase.getCustomerEmail());
        response.setCustomerName(purchase.getCustomerName());
        response.setIsUsed(purchase.getIsUsed());
        response.setMatchId(purchase.getMatch() != null ? purchase.getMatch().getId() : null);
        response.setQuantity(purchase.getQuantity());
        response.setOrderId(purchase.getOrderId());
        response.setConfirmationNumber(purchase.getConfirmationNumber());
        response.setPurchaseDate(purchase.getPurchaseDate());
        response.setPaymentMethod(purchase.getPaymentMethod());
        return response;
    }
}