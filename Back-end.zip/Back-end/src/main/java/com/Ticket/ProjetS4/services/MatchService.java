package com.Ticket.ProjetS4.services;

import java.util.List;
import java.util.stream.Collectors;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.Ticket.ProjetS4.dto.MatchRequest;
import com.Ticket.ProjetS4.dto.MatchResponse;
import com.Ticket.ProjetS4.models.Match;
import com.Ticket.ProjetS4.repository.MatchRepository;

@Service
public class MatchService {
    private final MatchRepository matchRepository;

    public MatchService(MatchRepository matchRepository) {
        this.matchRepository = matchRepository;
    }

    public MatchResponse createMatch(MatchRequest request) {
        Match match = new Match();
        mapRequestToMatch(request, match);
        Match savedMatch = matchRepository.save(match);
        return mapMatchToResponse(savedMatch);
    }

    public List<MatchResponse> getAllMatches() {
        return matchRepository.findAll().stream()
                .map(this::mapMatchToResponse)
                .collect(Collectors.toList());
    }

    public MatchResponse getMatchById(Long id) {
        Match match = matchRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Match not found with id: " + id));
        return mapMatchToResponse(match);
    }

    public MatchResponse updateMatch(Long id, MatchRequest request) {
        Match match = matchRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Match not found"));

        mapRequestToMatch(request, match); // updated logic

        matchRepository.save(match);
        return mapMatchToResponse(match);
    }

    public void deleteMatch(Long id) {
        if (!matchRepository.existsById(id)) {
            throw new RuntimeException("Match not found with id: " + id);
        }
        matchRepository.deleteById(id);
    }

    public MatchResponse setHotMatch(Long id, boolean isHot) {
        Match match = matchRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Match not found with id: " + id));
        match.setHotMatch(isHot);
        Match updatedMatch = matchRepository.save(match);
        return mapMatchToResponse(updatedMatch);
    }

    private void mapRequestToMatch(MatchRequest request, Match match) {
        match.setTeam1(request.getTeam1());
        match.setTeam2(request.getTeam2());
        match.setMatchDate(request.getMatchDate());
        match.setVenue(request.getVenue());
        match.setVenueCapacity(request.getVenueCapacity());
        match.setDescription(request.getDescription());
        match.setHotMatch(request.isHotMatch());
        match.setSportType(request.getSportType());
        match.setTicketPrice(request.getTicketPrice());
        // Also set the price field to be consistent
        match.setPrice((double) request.getTicketPrice());
        match.setPhoto(request.getImageUrl());
        match.setTicketAvailability(request.getTicketAvailability()); // ✅ NEW
    }

    private MatchResponse mapMatchToResponse(Match match) {
        MatchResponse response = new MatchResponse();
        response.setId(match.getId());
        response.setTeam1(match.getTeam1());
        response.setTeam2(match.getTeam2());
        response.setMatchDate(match.getMatchDate());
        response.setVenue(match.getVenue());
        response.setVenueCapacity(match.getVenueCapacity());
        response.setDescription(match.getDescription());
        response.setHotMatch(match.isHotMatch());
        response.setSportType(match.getSportType());
        response.setTicketPrice(match.getTicketPrice());
        response.setImageUrl(match.getPhoto());
        response.setTicketAvailability(match.getTicketAvailability()); // ✅ NEW
        return response;
    }

    public void saveMatchPhoto(Long matchId, MultipartFile file) throws IOException {
        Match match = matchRepository.findById(matchId)
            .orElseThrow(() -> new RuntimeException("Match not found"));

        String filename = matchId + "_" + file.getOriginalFilename();
        Path uploadDir = Paths.get("uploads");
        Files.createDirectories(uploadDir);

        Path filePath = uploadDir.resolve(filename);
        Files.write(filePath, file.getBytes());

        match.setPhoto(filename);
        matchRepository.save(match);
    }

    public byte[] getMatchPhoto(Long matchId) {
        Match match = matchRepository.findById(matchId)
                .orElseThrow(() -> new RuntimeException("Match not found"));

        if (match.getPhoto() == null)
            return null;

        Path filePath = Paths.get("uploads").resolve(match.getPhoto());
        try {
            return Files.readAllBytes(filePath);
        } catch (IOException e) {
            return null;
        }
    }

    public Match saveMatch(Match match) {
        Match newMatch = new Match();
        newMatch.setTeam1(match.getTeam1());
        newMatch.setTeam2(match.getTeam2());
        newMatch.setSport(match.getSport());
        newMatch.setMatchDate(match.getMatchDate());
        newMatch.setVenue(match.getVenue());
        newMatch.setPrice(match.getPrice());
        newMatch.setTickets(match.getTickets());
        newMatch.setHotMatch(match.isHotMatch());
        newMatch.setDescription(match.getDescription());
        newMatch.setTicketAvailability(match.getTicketAvailability());
        return matchRepository.save(newMatch);
    }

    // Enhanced method with better error handling
    public Match getMatchEntityById(Long id) {
        try {
            return matchRepository.findById(id).orElse(null);
        } catch (Exception e) {
            System.err.println("Error fetching match with id " + id + ": " + e.getMessage());
            return null;
        }
    }
}
