package com.Ticket.ProjetS4.models;


public enum Role {
    USER, ADMIN
}
