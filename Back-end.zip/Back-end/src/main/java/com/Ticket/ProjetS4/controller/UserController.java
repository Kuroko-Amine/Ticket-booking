package com.Ticket.ProjetS4.controller;

import java.util.Optional;
import java.util.List;
import com.Ticket.ProjetS4.dto.Userdto;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.Ticket.ProjetS4.models.User;
import com.Ticket.ProjetS4.models.Role;
import com.Ticket.ProjetS4.repository.UserRepository;
import com.Ticket.ProjetS4.services.UserService;

@RestController
@RequestMapping("/api/users")  // Changed to match frontend expectations
@CrossOrigin(origins = "http://localhost:8080")  // Adjust this to your frontend URL
public class UserController {

    private final UserService userService;
    private final UserRepository userRepository;

    public UserController(UserService userService, UserRepository userRepository) {
        this.userService = userService;
        this.userRepository = userRepository;
    }

    @GetMapping
    public ResponseEntity<List<Userdto>> getAllUsers() {
        try {
            List<Userdto> users = userService.getAllUsers();
            return ResponseEntity.ok(users);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        try {
            User savedUser = userService.saveUser(user);
            return ResponseEntity.ok(savedUser);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        try {
            userRepository.deleteById(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/{id}/promote")
    public ResponseEntity<?> promoteUser(@PathVariable Long id) {
    try {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND, "User not found"));
        
        // Check current role
        if (user.getRole() == Role.ADMIN) {
            return ResponseEntity.badRequest().body("User is already an admin");
        }
        
        // Promote to admin
        user.setRole(Role.ADMIN);
        User updatedUser = userRepository.save(user);
        
        return ResponseEntity.ok(updatedUser);
    } catch (ResponseStatusException e) {
        throw e; // Re-throw not found exceptions
    } catch (Exception e) {
        return ResponseEntity.internalServerError()
            .body("Error promoting user: " + e.getMessage());
    }
}
}