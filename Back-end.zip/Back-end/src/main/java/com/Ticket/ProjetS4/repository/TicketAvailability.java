package com.Ticket.ProjetS4.repository;

public enum TicketAvailability {

}
