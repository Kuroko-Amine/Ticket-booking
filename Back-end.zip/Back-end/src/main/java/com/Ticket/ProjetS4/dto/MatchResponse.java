package com.Ticket.ProjetS4.dto;

import java.time.LocalDateTime;
import com.Ticket.ProjetS4.models.TicketPurchase;

public class MatchResponse {
    private Long id;
    private String team1;
    private String team2;
    private LocalDateTime matchDate;
    private String venue;
    private int venueCapacity;
    private String description;
    private boolean isHotMatch;
    private String sportType;
    private double ticketPrice;
    private String imageUrl;
    private TicketPurchase ticket;
    private String ticketAvailability;
    
    public String getSportType() {
        return sportType;
    }

    public void setSportType(String sportType) {
        this.sportType = sportType;
    }

    public double getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(double ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }


    public MatchResponse() {
    }
    public MatchResponse(double basePrice, int capacity) {
        this.ticketPrice = basePrice;
        this.venueCapacity = capacity;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTeam1() {
        return team1;
    }

    public void setTeam1(String team1) {
        this.team1 = team1;
    }

    public String getTeam2() {
        return team2;
    }

    public void setTeam2(String team2) {
        this.team2 = team2;
    }

    public LocalDateTime getMatchDate() {
        return matchDate;
    }

    public void setMatchDate(LocalDateTime matchDate) {
        this.matchDate = matchDate;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public int getVenueCapacity() {
        return venueCapacity;
    }

    public void setVenueCapacity(int venueCapacity) {
        this.venueCapacity = venueCapacity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isHotMatch() {
        return isHotMatch;
    }

    public void setHotMatch(boolean hotMatch) {
        this.isHotMatch = hotMatch;
    }

    public TicketPurchase getTicket() {
        return ticket;
    }

    public void setTicket(TicketPurchase ticket) {
        this.ticket = ticket;
    }
    public String getTicketAvailability() {
        return ticketAvailability;
    }

    public void setTicketAvailability(String ticketAvailability) {
        this.ticketAvailability = ticketAvailability;
    }
}