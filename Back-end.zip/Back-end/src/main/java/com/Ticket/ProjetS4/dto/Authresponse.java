package com.Ticket.ProjetS4.dto;



public class Authresponse {
    private String token;

    public Authresponse(String token) { this.token = token; }
    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
}



