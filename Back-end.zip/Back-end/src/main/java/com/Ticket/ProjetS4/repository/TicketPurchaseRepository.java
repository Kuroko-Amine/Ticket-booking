package com.Ticket.ProjetS4.repository;

import com.Ticket.ProjetS4.models.TicketPurchase;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface TicketPurchaseRepository extends JpaRepository<TicketPurchase, Long> {
    List<TicketPurchase> findByCustomerEmailOrderByPurchaseDateDesc(String email);
    Optional<TicketPurchase> findByConfirmationNumber(String confirmationNumber);
    Optional<TicketPurchase> findTicketByMatchId(Long matchId);
    List<TicketPurchase> findByMatchId(Long matchId);
}
