package com.Ticket.ProjetS4.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginRequest {
    private String email;
    private String password;
    public String getPassword() {
        return password;
    }
    public String getEmail() {
        return email;
    }
}

