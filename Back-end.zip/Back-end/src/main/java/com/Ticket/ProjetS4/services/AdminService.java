// AdminService.java
package com.Ticket.ProjetS4.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Ticket.ProjetS4.models.Match;
import com.Ticket.ProjetS4.models.Role;
import com.Ticket.ProjetS4.models.TicketPurchase;
import com.Ticket.ProjetS4.models.User;
import com.Ticket.ProjetS4.repository.MatchRepository;
import com.Ticket.ProjetS4.repository.TicketPurchaseRepository;
import com.Ticket.ProjetS4.repository.UserRepository;

@Service
public class AdminService {
    private final UserRepository userRepository;
    private final MatchRepository matchRepository;
    private final TicketPurchaseRepository ticketRepository;

    public AdminService(UserRepository userRepository, MatchRepository matchRepository, TicketPurchaseRepository ticketRepository) {
        this.userRepository = userRepository;
        this.matchRepository = matchRepository;
        this.ticketRepository = ticketRepository;
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }

    public void promoteUserToAdmin(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        user.setRole(Role.ADMIN);
        userRepository.save(user);
    }

    public Match createMatch(Match match) {
        return matchRepository.save(match);
    }

    /*public TicketPurchase createTicket(TicketPurchase ticket, Long matchId) {
        Match match = matchRepository.findById(matchId)
                .orElseThrow(() -> new RuntimeException("Match not found"));
        ticket.setMatch(match);
        return ticketRepository.save(ticket);
    }*/

    public Match markMatchAsHot(Long matchId) {
        Match match = matchRepository.findById(matchId)
                .orElseThrow(() -> new RuntimeException("Match not found"));
        match.setHotMatch(true);
        return matchRepository.save(match);
    }
}