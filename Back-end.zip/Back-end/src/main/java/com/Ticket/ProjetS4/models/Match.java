package com.Ticket.ProjetS4.models;

import java.time.LocalDateTime;
import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "matches")
public class Match {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String team1;
    
    @Column(nullable = false)
    private String team2;
    
    @Column(nullable = false)
    private LocalDateTime matchDate;
    
    @Column(nullable = false)
    private String venue;
    
    @Column(nullable = false)
    private int venueCapacity;
    
    @Column(nullable = false)
    private String sportType;

    @Column(nullable = false)
    private double ticketPrice;

    private Double price;
    private String description;
    private boolean isHotMatch = false;
    private String sport;
    private String ticketAvailability;
    
    private int tickets;
    
    @OneToMany(mappedBy = "match", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<TicketPurchase> ticketPurchases;
    
    @Column(name = "photo")
    private String photo;

    public Match() {
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSportType() {
        return sportType;
    }

    public void setSportType(String sportType) {
        this.sportType = sportType;
    }

    public double getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(double ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    public String getTeam1() {
        return team1;
    }

    public void setTeam1(String team1) {
        this.team1 = team1;
    }

    public String getTeam2() {
        return team2;
    }

    public void setTeam2(String team2) {
        this.team2 = team2;
    }

    public LocalDateTime getMatchDate() {
        return matchDate;
    }

    public void setMatchDate(LocalDateTime matchDate) {
        this.matchDate = matchDate;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public int getVenueCapacity() {
        return venueCapacity;
    }

    public void setVenueCapacity(int venueCapacity) {
        this.venueCapacity = venueCapacity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isHotMatch() {
        return isHotMatch;
    }

    public void setHotMatch(boolean hotMatch) {
        this.isHotMatch = hotMatch;
    }

    public List<TicketPurchase> getTicketPurchases() {
        return ticketPurchases;
    }

    public void setTicketPurchases(List<TicketPurchase> ticketPurchases) {
        this.ticketPurchases = ticketPurchases;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getTicketAvailability() {
        return ticketAvailability;
    }
    
    public void setTicketAvailability(String ticketAvailability) {
        this.ticketAvailability = ticketAvailability;
    }

    public String getSport() {
        return sport;
    }

    public void setSport(String sport) {
        this.sport = sport;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public int getTickets() {
        return tickets;
    }

    public void setTickets(int tickets) {
        this.tickets = tickets;
    }
}