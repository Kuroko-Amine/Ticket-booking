package com.Ticket.ProjetS4.controller;

import com.Ticket.ProjetS4.dto.TicketPurchaseRequest;
import com.Ticket.ProjetS4.dto.TicketPurchaseResponse;
import com.Ticket.ProjetS4.services.TicketPurchaseService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/purchases")
@CrossOrigin(origins = {"http://localhost:8080", "http://localhost:3000"})
public class TicketPurchaseController {
    private final TicketPurchaseService ticketPurchaseService;

    public TicketPurchaseController(TicketPurchaseService ticketPurchaseService) {
        this.ticketPurchaseService = ticketPurchaseService;
    }

    @PostMapping
    public ResponseEntity<Object> createPurchase(@RequestBody TicketPurchaseRequest request) {
        try {
            System.out.println("Creating purchase with request: " + request.getCustomerEmail() + 
                             " for match: " + request.getMatchId());
            
            TicketPurchaseResponse response = ticketPurchaseService.createPurchase(request);
            
            // Wrap response in a success object
            Map<String, Object> successResponse = new HashMap<>();
            successResponse.put("success", true);
            successResponse.put("data", response);
            successResponse.put("message", "Purchase created successfully");
            
            return ResponseEntity.ok(successResponse);
        } catch (Exception e) {
            System.err.println("Error creating purchase: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("error", "Failed to create purchase");
            errorResponse.put("message", e.getMessage());
            errorResponse.put("timestamp", System.currentTimeMillis());
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @GetMapping("/customer/{customerEmail}")
    public ResponseEntity<Object> getPurchasesByCustomer(@PathVariable String customerEmail) {
        try {
            List<TicketPurchaseResponse> purchases = ticketPurchaseService.getPurchasesByCustomerEmail(customerEmail);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", purchases);
            response.put("count", purchases.size());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("error", "Failed to retrieve purchases");
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Object> getPurchaseById(@PathVariable Long id) {
        try {
            TicketPurchaseResponse purchase = ticketPurchaseService.getPurchaseById(id);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", purchase);
            
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("error", "Purchase not found");
            errorResponse.put("id", id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
    }

    @GetMapping("/confirmation/{confirmationNumber}")
    public ResponseEntity<Object> getPurchaseByConfirmation(@PathVariable String confirmationNumber) {
        try {
            TicketPurchaseResponse purchase = ticketPurchaseService.getPurchaseByConfirmationNumber(confirmationNumber);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", purchase);
            
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("error", "Purchase not found");
            errorResponse.put("confirmationNumber", confirmationNumber);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
    }

    @GetMapping("/match/{matchId}")
    public ResponseEntity<Object> getPurchasesByMatch(@PathVariable Long matchId) {
        try {
            List<TicketPurchaseResponse> purchases = ticketPurchaseService.getPurchasesByMatchId(matchId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", purchases);
            response.put("count", purchases.size());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("error", "Failed to retrieve purchases for match");
            errorResponse.put("matchId", matchId);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> healthCheck() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "TicketPurchaseController");
        response.put("timestamp", System.currentTimeMillis());
        return ResponseEntity.ok(response);
    }
}
