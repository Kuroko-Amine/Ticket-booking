package com.Ticket.ProjetS4.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Ticket.ProjetS4.models.Match;

public interface MatchRepository extends JpaRepository<Match, Long> {
    List<Match> findByIsHotMatch(boolean isHotMatch);
}