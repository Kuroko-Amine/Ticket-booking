package com.Ticket.ProjetS4.controller;

import com.Ticket.ProjetS4.models.Match;
import com.Ticket.ProjetS4.services.MatchService;
import com.Ticket.ProjetS4.repository.TicketPurchaseRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/tickets")
@CrossOrigin(origins = {"http://localhost:8080", "http://localhost:3000"})
public class TicketController {
    private final MatchService matchService;
    private final TicketPurchaseRepository ticketRepository;

    public TicketController(MatchService matchService, TicketPurchaseRepository ticketRepository) {
        this.matchService = matchService;
        this.ticketRepository = ticketRepository;
    }

    @GetMapping("/match/{matchId}")
    public ResponseEntity<Map<String, Object>> getTicketForMatch(@PathVariable Long matchId) {
        try {
            System.out.println("Received request for match ID: " + matchId);
            
            Optional<Match> matchOpt = ticketRepository.findTicketByMatchId(matchId)
                    .map(ticketPurchase -> ticketPurchase.getMatch());
            if (matchOpt.isEmpty()) {
                System.out.println("No match found for ID: " + matchId);
                Map<String, Object> errorResponse = new HashMap<>();
                errorResponse.put("error", "Match not found");
                errorResponse.put("matchId", matchId);
                errorResponse.put("success", false);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
            }
            
            Match match = matchOpt.get();
            System.out.println("Found match: " + match.getTeam1() + " vs " + match.getTeam2());
            
            Map<String, Object> ticketInfo = new HashMap<>();
            ticketInfo.put("success", true);
            ticketInfo.put("id", match.getId());
            ticketInfo.put("eventName", match.getTeam1() + " vs " + match.getTeam2());
            ticketInfo.put("venue", match.getVenue());
            ticketInfo.put("price", match.getPrice() != null ? match.getPrice() : match.getTicketPrice());
            ticketInfo.put("matchDate", match.getMatchDate());
            ticketInfo.put("venueCapacity", match.getVenueCapacity());
            ticketInfo.put("availableTickets", match.getTickets());
            ticketInfo.put("team1", match.getTeam1());
            ticketInfo.put("team2", match.getTeam2());
            ticketInfo.put("sportType", match.getSportType());
            
            return ResponseEntity.ok(ticketInfo);
        } catch (Exception e) {
            System.err.println("Error in getTicketForMatch: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "Internal server error");
            errorResponse.put("message", e.getMessage());
            errorResponse.put("success", false);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> createTicket(@RequestBody Map<String, Object> request) {
        try {
            System.out.println("Creating ticket with data: " + request);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Ticket created successfully");
            response.put("ticketId", System.currentTimeMillis());
            response.put("timestamp", System.currentTimeMillis());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            System.err.println("Error creating ticket: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "Failed to create ticket");
            errorResponse.put("message", e.getMessage());
            errorResponse.put("success", false);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> healthCheck() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "TicketController");
        response.put("timestamp", System.currentTimeMillis());
        return ResponseEntity.ok(response);
    }
}