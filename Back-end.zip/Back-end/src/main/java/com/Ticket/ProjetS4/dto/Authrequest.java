package com.Ticket.ProjetS4.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Authrequest {
    private String email;
    private String password;
}

