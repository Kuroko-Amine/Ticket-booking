package com.Ticket.ProjetS4.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import com.Ticket.ProjetS4.models.Match;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import org.springframework.http.MediaType;

import com.Ticket.ProjetS4.dto.MatchRequest;
import com.Ticket.ProjetS4.dto.MatchResponse;
import com.Ticket.ProjetS4.services.MatchService;

@RestController
@RequestMapping("/api/matches")
@CrossOrigin(origins = "http://localhost:8080") // Adjust to your frontend URL
public class MatchController {
    private final MatchService matchService;

    public MatchController(MatchService matchService) {
        this.matchService = matchService;
    }

    @PostMapping
    public ResponseEntity<MatchResponse> createMatch(@RequestBody MatchRequest request) {
        try {
            MatchResponse response = matchService.createMatch(request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping
    public List<MatchResponse> getAllMatches() {
        return matchService.getAllMatches();
    }

    @GetMapping("/{id}")
    public ResponseEntity<MatchResponse> getMatchById(@PathVariable Long id) {
        try {
            MatchResponse response = matchService.getMatchById(id);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<MatchResponse> updateMatch(
            @PathVariable Long id,
            @RequestBody MatchRequest request) {
        try {
            MatchResponse response = matchService.updateMatch(id, request);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMatch(@PathVariable Long id) {
        try {
            matchService.deleteMatch(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/{id}/hot")
    public ResponseEntity<MatchResponse> setHotMatch(
            @PathVariable Long id,
            @RequestParam boolean isHot) {
        try {
            MatchResponse response = matchService.setHotMatch(id, isHot);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/{id}/photo")
    public ResponseEntity<String> uploadMatchPhoto(@PathVariable Long id, @RequestParam("file") MultipartFile file) {
        try {
            matchService.saveMatchPhoto(id, file);
            return ResponseEntity.ok("Photo uploaded successfully.");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Photo upload failed due to an I/O error.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Photo upload failed.");
        }
    }

    @GetMapping("/{id}/photo")
    public ResponseEntity<byte[]> getMatchPhoto(@PathVariable Long id) {
        byte[] imageData = matchService.getMatchPhoto(id);
        if (imageData != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG); // Or IMAGE_PNG
            return new ResponseEntity<>(imageData, headers, HttpStatus.OK);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Fixed endpoint - this was causing the 500 error
    @GetMapping("/{id}/info")
    public ResponseEntity<Map<String, Object>> getMatchInfo(@PathVariable Long id) {
        try {
            Match match = matchService.getMatchEntityById(id);
            if (match == null) {
                return ResponseEntity.notFound().build();
            }
            
            // Create a simple map response instead of using MatchResponse constructor
            Map<String, Object> matchInfo = new HashMap<>();
            
            // Use ticketPrice if price is null, otherwise use price
            Double price = match.getPrice() != null ? match.getPrice() : match.getTicketPrice();
            
            matchInfo.put("price", price);
            matchInfo.put("venueCapacity", match.getVenueCapacity());
            matchInfo.put("team1", match.getTeam1());
            matchInfo.put("team2", match.getTeam2());
            matchInfo.put("venue", match.getVenue());
            matchInfo.put("matchDate", match.getMatchDate());
            
            return ResponseEntity.ok(matchInfo);
        } catch (Exception e) {
            // Log the error for debugging
            System.err.println("Error in getMatchInfo: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
